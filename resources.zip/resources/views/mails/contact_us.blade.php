<h1 style="text-align: center">New Message from your client!</h1>

<h5>Client Name : {{ $name }}</h5>
<h5>Client Email : {{ $email }}</h5>
<p>Messages : {{ $messages }}</p>