<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © NirapodHost.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Developed By <i class="mdi mdi-heart text-danger"></i> by <a href="{{ url('/') }}" target="_blank" class="text-reset">NirapodHost</a>
                </div>
            </div>
        </div>
    </div>
</footer>